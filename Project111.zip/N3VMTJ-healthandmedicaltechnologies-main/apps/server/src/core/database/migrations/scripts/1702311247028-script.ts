import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {
    try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('0bbdabf5-e787-44f5-803d-ea3a7026aafd', '1Marge.Dietrich5@gmail.com', 'Bob Smith', 'https://i.imgur.com/YfJQV5z.png?id=3', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('6993e202-0cfe-4b43-a644-40254a3ea2a5', '7Kamryn30@gmail.com', 'David Brown', 'https://i.imgur.com/YfJQV5z.png?id=9', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('ef9fbd03-26d3-43a4-813f-147d574500c4', '13Kathlyn.Kemmer81@yahoo.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=15', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('0b84f443-63e5-4323-9f2d-bf053e3a91ab', '25Kraig29@hotmail.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=27', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('e8742afe-950d-4b29-8846-137fe633cf77', '31Annabell.Harris@gmail.com', 'Bob Smith', 'https://i.imgur.com/YfJQV5z.png?id=33', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('3fd0c4e2-13d6-4dcd-9faa-c5955026841a', '37Alfonso25@gmail.com', 'Bob Smith', 'https://i.imgur.com/YfJQV5z.png?id=39', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('9cce7311-3ed0-43d2-ab6f-9c81a4bb0bd6', '43Norwood_Greenholt46@hotmail.com', 'Bob Smith', 'https://i.imgur.com/YfJQV5z.png?id=45', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('18e81622-1f0f-4c76-87d7-91f881f279a2', '49Reece.Kovacek98@yahoo.com', 'Alice Johnson', 'https://i.imgur.com/YfJQV5z.png?id=51', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('398951da-aecc-439c-936c-63917ded202f', '55Barbara_Herman50@yahoo.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=57', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('c27f6449-ae7c-44dd-99da-62e273886ea6', 'Doctor Contact Info', 'A new clinic has opened near you', 'Dr. Sarah Lee', '64Victor_Carroll63@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=65', 'https://i.imgur.com/YfJQV5z.png?id=66', '18e81622-1f0f-4c76-87d7-91f881f279a2');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('289d3e09-dad1-4fb8-93e7-dea4b0a78bf2', 'Health Tips', 'Our clinic has updated its opening hours', 'Health Newsletter', '71Jovany75@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=72', 'https://i.imgur.com/YfJQV5z.png?id=73', '9cce7311-3ed0-43d2-ab6f-9c81a4bb0bd6');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9aab4b95-623f-4c65-adfc-2edec268b63a', 'New Clinic Alert', 'Check out these 5 tips for better heart health', 'MediClinic Admin', '78Elmira.Greenholt99@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=79', 'https://i.imgur.com/YfJQV5z.png?id=80', '398951da-aecc-439c-936c-63917ded202f');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('d0891799-cd46-4105-bf27-0c2a98990f9e', 'Clinic Update', 'Check out these 5 tips for better heart health', 'MediClinic Admin', '85Jasper.Reilly20@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=86', 'https://i.imgur.com/YfJQV5z.png?id=87', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('4ac72316-4fe2-4e64-bc62-c3e2451de0e4', 'Health Tips', 'Our clinic has updated its opening hours', 'Health Newsletter', '92Jorge_Mueller61@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=93', 'https://i.imgur.com/YfJQV5z.png?id=94', '0b84f443-63e5-4323-9f2d-bf053e3a91ab');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('14a02130-6b60-4674-850d-99e160e9c2db', 'Clinic Update', 'Dont forget your appointment tomorrow at 10 AM', 'Local Health Authority', '99Anne_Rutherford@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=100', 'https://i.imgur.com/YfJQV5z.png?id=101', 'e8742afe-950d-4b29-8846-137fe633cf77');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('3e3e6282-3152-4579-ac05-ed5b54cb1a20', 'New Clinic Alert', 'Check out these 5 tips for better heart health', 'Health Newsletter', '106Blanca81@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=107', 'https://i.imgur.com/YfJQV5z.png?id=108', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('078aa697-fc2b-459d-9db4-997fc362dd40', 'Appointment Reminder', 'Our clinic has updated its opening hours', 'Local Health Authority', '113Katelyn_Corwin36@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=114', 'https://i.imgur.com/YfJQV5z.png?id=115', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9ee7e2ca-a08e-41eb-a1f2-8ae366bcc031', 'Clinic Update', 'Here is the contact info for your new doctor', 'Dr. Sarah Lee', '120Ruth84@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=121', 'https://i.imgur.com/YfJQV5z.png?id=122', '3fd0c4e2-13d6-4dcd-9faa-c5955026841a');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('60fd55b9-3326-4976-9619-bfcf373246ea', 'Clinic Update', 'A new clinic has opened near you', 'Dr. Sarah Lee', '127Leon.Baumbach-Sauer@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=128', 'https://i.imgur.com/YfJQV5z.png?id=129', '18e81622-1f0f-4c76-87d7-91f881f279a2');

INSERT INTO "hospital" ("id", "name", "address") VALUES ('93e1ae95-e99a-4fcc-843f-52de7321e644', 'Riverside Medical Center', '132 330 W Broadway, New York, NY 10013');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('3917db3e-1008-45f0-ae65-9fb1f4cf9b00', 'City Health Clinic', '135 91 Christopher St, New York, NY 10014');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('fc8b56ec-b90d-4e34-a8a7-9c0056176344', 'Green Valley Healthcare', '138 443 E 6th St, New York, NY 10009');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('0fb2163c-e0c9-4a99-8255-dbaaabe1203f', 'Mercy General Hospital', '141 443 E 6th St, New York, NY 10009');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('5e8f363d-0314-44d6-8d1a-211e63207f57', 'Sunrise Specialty Hospital', '144 91 Christopher St, New York, NY 10014');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('3568f1a1-2857-4d45-9960-8b2c7c882c81', 'Sunrise Specialty Hospital', '147 443 E 6th St, New York, NY 10009');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('054d60c6-3525-4166-952e-f9abfdbfd9ff', 'Mercy General Hospital', '150 330 W Broadway, New York, NY 10013');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('c5a9e84e-ff58-4f92-a827-b92001119261', 'Mercy General Hospital', '153 18 W 29th St, New York, NY 10001');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('50a406a2-998e-4830-bde5-6b34337d4f25', 'Green Valley Healthcare', '156 330 W Broadway, New York, NY 10013');
INSERT INTO "hospital" ("id", "name", "address") VALUES ('f2676370-6eb9-4322-8ce4-3115df93306b', 'Mercy General Hospital', '159 91 Christopher St, New York, NY 10014');

INSERT INTO "clinic" ("id", "name", "address") VALUES ('b01bb9b5-6f3f-4dc1-a8a7-fb1b2de157c5', 'Greenwood Medical Center', '162 330 W Broadway, New York, NY 10013');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('28cfc03f-c504-4674-a5d3-1af00de8857f', 'Maple Tree Medical', '165 18 W 29th St, New York, NY 10001');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('bcc136c1-6ab1-4a59-b15f-add9c112c4e4', 'Oceanview Healthcare', '168 136 E 13th St, New York, NY 10003');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('866ad7c4-d272-4bc5-9a29-320f5b1f80a4', 'Sunrise Health Clinic', '171 18 W 29th St, New York, NY 10001');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('408472a4-23e7-4057-8627-50400e095066', 'Oceanview Healthcare', '174 42 E 20th St, New York, NY 10003');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('25312fbf-6069-46a9-b61c-455727c9624f', 'Maple Tree Medical', '177 42 E 20th St, New York, NY 10003');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('0500088b-8030-4d7d-87ad-3316c796f4f4', 'Maple Tree Medical', '180 330 W Broadway, New York, NY 10013');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('30aea388-95e4-486b-af20-426395176988', 'Riverside Family Clinic', '183 18 Spring St, New York, NY 10012');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('aef51343-a933-4bfe-ad0e-995e8834b504', 'Greenwood Medical Center', '186 42 E 20th St, New York, NY 10003');
INSERT INTO "clinic" ("id", "name", "address") VALUES ('f779afd5-b9ed-4e9c-bd0c-abdd12c3c099', 'Sunrise Health Clinic', '189 430 Lafayette St, New York, NY 10003');

INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('b61473ca-00aa-4b3e-aab6-84cc37e2c5a1', 'Mohammed Ali', '1234567890');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('13b1a7e5-42dc-4e1c-af73-1eac5c182783', 'John Doe', '1987654321');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('a9e1b5a4-75ab-461f-88d6-09983a5e868e', 'Sandra Dee', '1122334455');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('d0561564-b9b4-4064-93c4-6d3c4c1f6e0f', 'Alex Johnson', '1223344556');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('7595c743-bf4b-4d1c-8d6a-e263dae51d6d', 'Sandra Dee', '1234567890');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('6918083d-e671-43a5-8312-b10bc33d111d', 'Sandra Dee', '1223344556');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('aeacbcf8-52c8-40a6-bad4-58369fc49e7c', 'Mohammed Ali', '1234567890');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('d1f870a5-6ec2-4edf-b0d8-8c973498dadb', 'Mohammed Ali', '1987654321');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('ce0ee530-f009-4455-899c-b32ba5821f2f', 'Sandra Dee', '1122334455');
INSERT INTO "doctor" ("id", "name", "contactNumber") VALUES ('b71bafe1-82e7-4314-a15f-c7f32b2a1f1c', 'Mohammed Ali', '1987654321');

INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('80b0a199-170a-4b23-9eba-00a6e8704ba0', '2024-10-04T17:54:41.943Z', '398951da-aecc-439c-936c-63917ded202f', 'a9e1b5a4-75ab-461f-88d6-09983a5e868e');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('c5164957-b7e6-4310-ba0b-92a8521b6483', '2025-01-21T19:04:03.597Z', '9cce7311-3ed0-43d2-ab6f-9c81a4bb0bd6', 'aeacbcf8-52c8-40a6-bad4-58369fc49e7c');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('32bbfbe9-6e31-4f38-98ea-eec5a081fac6', '2023-07-24T22:42:08.802Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'd1f870a5-6ec2-4edf-b0d8-8c973498dadb');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('0b658c18-a711-4254-b54f-9f52abc9a2db', '2024-10-26T18:19:53.913Z', '6993e202-0cfe-4b43-a644-40254a3ea2a5', '13b1a7e5-42dc-4e1c-af73-1eac5c182783');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('977a42b6-4628-4989-8362-377e94ba6aea', '2024-10-27T01:21:07.518Z', '18e81622-1f0f-4c76-87d7-91f881f279a2', 'aeacbcf8-52c8-40a6-bad4-58369fc49e7c');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('c5dc8421-4ec9-4aaf-949a-90d4e79e9523', '2024-06-14T15:32:17.591Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'aeacbcf8-52c8-40a6-bad4-58369fc49e7c');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('4f3c372c-1763-4071-beac-4a79352aa7e3', '2023-09-20T02:46:58.227Z', '0bbdabf5-e787-44f5-803d-ea3a7026aafd', 'd0561564-b9b4-4064-93c4-6d3c4c1f6e0f');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('fb0a8dce-f61d-4512-88ab-b3d23e24811c', '2024-03-11T07:21:04.256Z', '18e81622-1f0f-4c76-87d7-91f881f279a2', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('f1a1e9fd-cc9f-4ffb-8f92-b390914ab7d6', '2025-02-07T16:23:52.389Z', 'e8742afe-950d-4b29-8846-137fe633cf77', 'b71bafe1-82e7-4314-a15f-c7f32b2a1f1c');
INSERT INTO "appointment" ("id", "dateTime", "userId", "doctorId") VALUES ('78fc7a25-94f3-49cf-8858-dbda7dae7a48', '2025-02-24T00:57:15.057Z', '0bbdabf5-e787-44f5-803d-ea3a7026aafd', '13b1a7e5-42dc-4e1c-af73-1eac5c182783');

INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('f2676370-6eb9-4322-8ce4-3115df93306b', 'd1f870a5-6ec2-4edf-b0d8-8c973498dadb', '2fad1986-dc91-4c8d-b6a8-5b534ed9c0a9');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('3568f1a1-2857-4d45-9960-8b2c7c882c81', 'b61473ca-00aa-4b3e-aab6-84cc37e2c5a1', '2db912ac-3506-4a5f-bef3-2289369124d1');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('93e1ae95-e99a-4fcc-843f-52de7321e644', '13b1a7e5-42dc-4e1c-af73-1eac5c182783', 'e546f95e-2773-463e-b9c5-b2976c10588a');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('3568f1a1-2857-4d45-9960-8b2c7c882c81', 'a9e1b5a4-75ab-461f-88d6-09983a5e868e', '61ac8874-6269-4bff-ac8b-f39e1dcdbd7d');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('3568f1a1-2857-4d45-9960-8b2c7c882c81', '13b1a7e5-42dc-4e1c-af73-1eac5c182783', 'bef2ec5f-193f-4808-8554-e2828553a7e1');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('5e8f363d-0314-44d6-8d1a-211e63207f57', '6918083d-e671-43a5-8312-b10bc33d111d', 'ae4feb32-ab83-4251-bf06-25aa50ae9f17');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('3917db3e-1008-45f0-ae65-9fb1f4cf9b00', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d', 'c5679880-955b-4276-a12b-aefbf1a7fd0e');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('50a406a2-998e-4830-bde5-6b34337d4f25', 'd1f870a5-6ec2-4edf-b0d8-8c973498dadb', '380d5be9-3ea6-4480-b0b4-2e8babb67e3c');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('5e8f363d-0314-44d6-8d1a-211e63207f57', 'a9e1b5a4-75ab-461f-88d6-09983a5e868e', '8c6b7cb9-7aa5-467a-b67a-013195f55ed3');
INSERT INTO "hospitaldoctor" ("hospitalId", "doctorId", "id") VALUES ('50a406a2-998e-4830-bde5-6b34337d4f25', 'b71bafe1-82e7-4314-a15f-c7f32b2a1f1c', 'a8d04f87-04e5-4126-a4bb-7308cd0648e9');

INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('28cfc03f-c504-4674-a5d3-1af00de8857f', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d', '066a6abb-aafb-4c5f-810d-c70967da81b3');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('b01bb9b5-6f3f-4dc1-a8a7-fb1b2de157c5', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d', 'd2e95bf7-8617-4fae-bf42-9297590bac83');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('25312fbf-6069-46a9-b61c-455727c9624f', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d', '9201541a-9758-4d6d-b90d-5da4f6221471');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('28cfc03f-c504-4674-a5d3-1af00de8857f', 'd0561564-b9b4-4064-93c4-6d3c4c1f6e0f', 'bf1a9390-c5ef-43d4-aa63-e2df3ca545e7');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('0500088b-8030-4d7d-87ad-3316c796f4f4', 'b71bafe1-82e7-4314-a15f-c7f32b2a1f1c', '04b172c7-aa17-4486-93e4-21c948234b45');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('0500088b-8030-4d7d-87ad-3316c796f4f4', 'd0561564-b9b4-4064-93c4-6d3c4c1f6e0f', '33965bc6-ad48-4ed1-9fb5-1e7f8e866d3f');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('30aea388-95e4-486b-af20-426395176988', 'd0561564-b9b4-4064-93c4-6d3c4c1f6e0f', 'd1147f18-e1de-49b8-9273-b2a3865a7278');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('28cfc03f-c504-4674-a5d3-1af00de8857f', 'a9e1b5a4-75ab-461f-88d6-09983a5e868e', '44e8d88d-a1c6-40d5-99f8-5c5e42186636');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('aef51343-a933-4bfe-ad0e-995e8834b504', '7595c743-bf4b-4d1c-8d6a-e263dae51d6d', 'a73f146e-7b06-4bb7-9309-6d2abaf06259');
INSERT INTO "clinicdoctor" ("clinicId", "doctorId", "id") VALUES ('aef51343-a933-4bfe-ad0e-995e8834b504', '13b1a7e5-42dc-4e1c-af73-1eac5c182783', 'f1b5264c-a938-4572-b93d-1762120de88f');
    `,
      )
    } catch (error) {
      // ignore
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
