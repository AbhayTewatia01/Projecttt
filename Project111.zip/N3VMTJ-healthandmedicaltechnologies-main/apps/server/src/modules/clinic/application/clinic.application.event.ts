export namespace ClinicApplicationEvent {
  export namespace ClinicCreated {
    export const key = 'clinic.application.clinic.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
