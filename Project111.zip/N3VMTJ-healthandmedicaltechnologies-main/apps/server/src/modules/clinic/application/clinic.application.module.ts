import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ClinicDomainModule } from '../domain'
import { ClinicController } from './clinic.controller'

@Module({
  imports: [AuthenticationDomainModule, ClinicDomainModule],
  controllers: [ClinicController],
  providers: [],
})
export class ClinicApplicationModule {}
