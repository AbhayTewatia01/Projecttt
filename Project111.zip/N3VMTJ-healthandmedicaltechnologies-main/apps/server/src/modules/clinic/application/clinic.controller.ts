import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Clinic, ClinicDomainFacade } from '@server/modules/clinic/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ClinicApplicationEvent } from './clinic.application.event'
import { ClinicCreateDto, ClinicUpdateDto } from './clinic.dto'

@Controller('/v1/clinics')
export class ClinicController {
  constructor(
    private eventService: EventService,
    private clinicDomainFacade: ClinicDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.clinicDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ClinicCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.clinicDomainFacade.create(body)

    await this.eventService.emit<ClinicApplicationEvent.ClinicCreated.Payload>(
      ClinicApplicationEvent.ClinicCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:clinicId')
  async findOne(@Param('clinicId') clinicId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.clinicDomainFacade.findOneByIdOrFail(
      clinicId,
      queryOptions,
    )

    return item
  }

  @Patch('/:clinicId')
  async update(
    @Param('clinicId') clinicId: string,
    @Body() body: ClinicUpdateDto,
  ) {
    const item = await this.clinicDomainFacade.findOneByIdOrFail(clinicId)

    const itemUpdated = await this.clinicDomainFacade.update(
      item,
      body as Partial<Clinic>,
    )
    return itemUpdated
  }

  @Delete('/:clinicId')
  async delete(@Param('clinicId') clinicId: string) {
    const item = await this.clinicDomainFacade.findOneByIdOrFail(clinicId)

    await this.clinicDomainFacade.delete(item)

    return item
  }
}
