export * from './clinic.domain.facade'
export * from './clinic.domain.module'
export * from './clinic.model'
