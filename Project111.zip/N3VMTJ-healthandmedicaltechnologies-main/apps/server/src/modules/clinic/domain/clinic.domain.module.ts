import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ClinicDomainFacade } from './clinic.domain.facade'
import { Clinic } from './clinic.model'

@Module({
  imports: [TypeOrmModule.forFeature([Clinic]), DatabaseHelperModule],
  providers: [ClinicDomainFacade, ClinicDomainFacade],
  exports: [ClinicDomainFacade],
})
export class ClinicDomainModule {}
