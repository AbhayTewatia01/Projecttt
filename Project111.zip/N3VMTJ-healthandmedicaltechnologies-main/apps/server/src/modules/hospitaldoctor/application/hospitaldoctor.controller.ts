import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  Hospitaldoctor,
  HospitaldoctorDomainFacade,
} from '@server/modules/hospitaldoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { HospitaldoctorApplicationEvent } from './hospitaldoctor.application.event'
import {
  HospitaldoctorCreateDto,
  HospitaldoctorUpdateDto,
} from './hospitaldoctor.dto'

@Controller('/v1/hospitaldoctors')
export class HospitaldoctorController {
  constructor(
    private eventService: EventService,
    private hospitaldoctorDomainFacade: HospitaldoctorDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.hospitaldoctorDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: HospitaldoctorCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.hospitaldoctorDomainFacade.create(body)

    await this.eventService.emit<HospitaldoctorApplicationEvent.HospitaldoctorCreated.Payload>(
      HospitaldoctorApplicationEvent.HospitaldoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:hospitaldoctorId')
  async findOne(
    @Param('hospitaldoctorId') hospitaldoctorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.hospitaldoctorDomainFacade.findOneByIdOrFail(
      hospitaldoctorId,
      queryOptions,
    )

    return item
  }

  @Patch('/:hospitaldoctorId')
  async update(
    @Param('hospitaldoctorId') hospitaldoctorId: string,
    @Body() body: HospitaldoctorUpdateDto,
  ) {
    const item =
      await this.hospitaldoctorDomainFacade.findOneByIdOrFail(hospitaldoctorId)

    const itemUpdated = await this.hospitaldoctorDomainFacade.update(
      item,
      body as Partial<Hospitaldoctor>,
    )
    return itemUpdated
  }

  @Delete('/:hospitaldoctorId')
  async delete(@Param('hospitaldoctorId') hospitaldoctorId: string) {
    const item =
      await this.hospitaldoctorDomainFacade.findOneByIdOrFail(hospitaldoctorId)

    await this.hospitaldoctorDomainFacade.delete(item)

    return item
  }
}
