import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { HospitaldoctorDomainFacade } from '@server/modules/hospitaldoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { HospitaldoctorApplicationEvent } from './hospitaldoctor.application.event'
import { HospitaldoctorCreateDto } from './hospitaldoctor.dto'

import { HospitalDomainFacade } from '../../hospital/domain'

@Controller('/v1/hospitals')
export class HospitaldoctorByHospitalController {
  constructor(
    private hospitalDomainFacade: HospitalDomainFacade,

    private hospitaldoctorDomainFacade: HospitaldoctorDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/hospital/:hospitalId/hospitaldoctors')
  async findManyHospitalId(
    @Param('hospitalId') hospitalId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.hospitalDomainFacade.findOneByIdOrFail(hospitalId)

    const items = await this.hospitaldoctorDomainFacade.findManyByHospital(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/hospital/:hospitalId/hospitaldoctors')
  async createByHospitalId(
    @Param('hospitalId') hospitalId: string,
    @Body() body: HospitaldoctorCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, hospitalId }

    const item = await this.hospitaldoctorDomainFacade.create(valuesUpdated)

    await this.eventService.emit<HospitaldoctorApplicationEvent.HospitaldoctorCreated.Payload>(
      HospitaldoctorApplicationEvent.HospitaldoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
