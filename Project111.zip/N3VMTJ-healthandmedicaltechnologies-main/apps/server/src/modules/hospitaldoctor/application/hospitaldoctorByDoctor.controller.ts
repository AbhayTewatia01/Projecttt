import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { HospitaldoctorDomainFacade } from '@server/modules/hospitaldoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { HospitaldoctorApplicationEvent } from './hospitaldoctor.application.event'
import { HospitaldoctorCreateDto } from './hospitaldoctor.dto'

import { DoctorDomainFacade } from '../../doctor/domain'

@Controller('/v1/doctors')
export class HospitaldoctorByDoctorController {
  constructor(
    private doctorDomainFacade: DoctorDomainFacade,

    private hospitaldoctorDomainFacade: HospitaldoctorDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/doctor/:doctorId/hospitaldoctors')
  async findManyDoctorId(
    @Param('doctorId') doctorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.doctorDomainFacade.findOneByIdOrFail(doctorId)

    const items = await this.hospitaldoctorDomainFacade.findManyByDoctor(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/doctor/:doctorId/hospitaldoctors')
  async createByDoctorId(
    @Param('doctorId') doctorId: string,
    @Body() body: HospitaldoctorCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, doctorId }

    const item = await this.hospitaldoctorDomainFacade.create(valuesUpdated)

    await this.eventService.emit<HospitaldoctorApplicationEvent.HospitaldoctorCreated.Payload>(
      HospitaldoctorApplicationEvent.HospitaldoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
