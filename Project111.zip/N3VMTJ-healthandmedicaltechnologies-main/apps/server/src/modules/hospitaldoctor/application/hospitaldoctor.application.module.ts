import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { HospitaldoctorDomainModule } from '../domain'
import { HospitaldoctorController } from './hospitaldoctor.controller'

import { HospitalDomainModule } from '../../../modules/hospital/domain'

import { HospitaldoctorByHospitalController } from './hospitaldoctorByHospital.controller'

import { DoctorDomainModule } from '../../../modules/doctor/domain'

import { HospitaldoctorByDoctorController } from './hospitaldoctorByDoctor.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    HospitaldoctorDomainModule,

    HospitalDomainModule,

    DoctorDomainModule,
  ],
  controllers: [
    HospitaldoctorController,

    HospitaldoctorByHospitalController,

    HospitaldoctorByDoctorController,
  ],
  providers: [],
})
export class HospitaldoctorApplicationModule {}
