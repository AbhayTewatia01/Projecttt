import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class HospitaldoctorCreateDto {
  @IsString()
  @IsOptional()
  hospitalId?: string

  @IsString()
  @IsOptional()
  doctorId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class HospitaldoctorUpdateDto {
  @IsString()
  @IsOptional()
  hospitalId?: string

  @IsString()
  @IsOptional()
  doctorId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
