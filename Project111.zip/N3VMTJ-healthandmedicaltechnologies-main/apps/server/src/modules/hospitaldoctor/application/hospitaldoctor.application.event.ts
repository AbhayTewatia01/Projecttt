export namespace HospitaldoctorApplicationEvent {
  export namespace HospitaldoctorCreated {
    export const key = 'hospitaldoctor.application.hospitaldoctor.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
