import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { HospitaldoctorDomainFacade } from './hospitaldoctor.domain.facade'
import { Hospitaldoctor } from './hospitaldoctor.model'

@Module({
  imports: [TypeOrmModule.forFeature([Hospitaldoctor]), DatabaseHelperModule],
  providers: [HospitaldoctorDomainFacade, HospitaldoctorDomainFacade],
  exports: [HospitaldoctorDomainFacade],
})
export class HospitaldoctorDomainModule {}
