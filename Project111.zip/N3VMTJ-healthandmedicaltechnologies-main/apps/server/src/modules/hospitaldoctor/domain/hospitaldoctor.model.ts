import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Hospital } from '../../../modules/hospital/domain'

import { Doctor } from '../../../modules/doctor/domain'

@Entity()
export class Hospitaldoctor {
  @Column({})
  hospitalId: string

  @ManyToOne(() => Hospital, parent => parent.hospitaldoctors)
  @JoinColumn({ name: 'hospitalId' })
  hospital?: Hospital

  @Column({})
  doctorId: string

  @ManyToOne(() => Doctor, parent => parent.hospitaldoctors)
  @JoinColumn({ name: 'doctorId' })
  doctor?: Doctor

  @PrimaryGeneratedColumn('uuid')
  id: string

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
