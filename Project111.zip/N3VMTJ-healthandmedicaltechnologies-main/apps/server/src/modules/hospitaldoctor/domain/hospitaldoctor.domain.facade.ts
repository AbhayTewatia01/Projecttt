import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Hospitaldoctor } from './hospitaldoctor.model'

import { Hospital } from '../../hospital/domain'

import { Doctor } from '../../doctor/domain'

@Injectable()
export class HospitaldoctorDomainFacade {
  constructor(
    @InjectRepository(Hospitaldoctor)
    private repository: Repository<Hospitaldoctor>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<Hospitaldoctor>): Promise<Hospitaldoctor> {
    return this.repository.save(values)
  }

  async update(
    item: Hospitaldoctor,
    values: Partial<Hospitaldoctor>,
  ): Promise<Hospitaldoctor> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Hospitaldoctor): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Hospitaldoctor> = {},
  ): Promise<Hospitaldoctor[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Hospitaldoctor> = {},
  ): Promise<Hospitaldoctor> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByHospital(
    item: Hospital,
    queryOptions: RequestHelper.QueryOptions<Hospitaldoctor> = {},
  ): Promise<Hospitaldoctor[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('hospital')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        hospitalId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByDoctor(
    item: Doctor,
    queryOptions: RequestHelper.QueryOptions<Hospitaldoctor> = {},
  ): Promise<Hospitaldoctor[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('doctor')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        doctorId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
