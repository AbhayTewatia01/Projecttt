export namespace HospitalApplicationEvent {
  export namespace HospitalCreated {
    export const key = 'hospital.application.hospital.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
