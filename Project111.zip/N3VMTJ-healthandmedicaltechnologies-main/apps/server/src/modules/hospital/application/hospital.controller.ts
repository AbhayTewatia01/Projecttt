import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Hospital, HospitalDomainFacade } from '@server/modules/hospital/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { HospitalApplicationEvent } from './hospital.application.event'
import { HospitalCreateDto, HospitalUpdateDto } from './hospital.dto'

@Controller('/v1/hospitals')
export class HospitalController {
  constructor(
    private eventService: EventService,
    private hospitalDomainFacade: HospitalDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.hospitalDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: HospitalCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.hospitalDomainFacade.create(body)

    await this.eventService.emit<HospitalApplicationEvent.HospitalCreated.Payload>(
      HospitalApplicationEvent.HospitalCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:hospitalId')
  async findOne(
    @Param('hospitalId') hospitalId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.hospitalDomainFacade.findOneByIdOrFail(
      hospitalId,
      queryOptions,
    )

    return item
  }

  @Patch('/:hospitalId')
  async update(
    @Param('hospitalId') hospitalId: string,
    @Body() body: HospitalUpdateDto,
  ) {
    const item = await this.hospitalDomainFacade.findOneByIdOrFail(hospitalId)

    const itemUpdated = await this.hospitalDomainFacade.update(
      item,
      body as Partial<Hospital>,
    )
    return itemUpdated
  }

  @Delete('/:hospitalId')
  async delete(@Param('hospitalId') hospitalId: string) {
    const item = await this.hospitalDomainFacade.findOneByIdOrFail(hospitalId)

    await this.hospitalDomainFacade.delete(item)

    return item
  }
}
