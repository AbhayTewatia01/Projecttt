import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { HospitalDomainModule } from '../domain'
import { HospitalController } from './hospital.controller'

@Module({
  imports: [AuthenticationDomainModule, HospitalDomainModule],
  controllers: [HospitalController],
  providers: [],
})
export class HospitalApplicationModule {}
