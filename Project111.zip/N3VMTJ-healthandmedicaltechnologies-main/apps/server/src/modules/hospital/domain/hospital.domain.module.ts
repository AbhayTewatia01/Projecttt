import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { HospitalDomainFacade } from './hospital.domain.facade'
import { Hospital } from './hospital.model'

@Module({
  imports: [TypeOrmModule.forFeature([Hospital]), DatabaseHelperModule],
  providers: [HospitalDomainFacade, HospitalDomainFacade],
  exports: [HospitalDomainFacade],
})
export class HospitalDomainModule {}
