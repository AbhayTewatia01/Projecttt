export * from './hospital.domain.facade'
export * from './hospital.domain.module'
export * from './hospital.model'
