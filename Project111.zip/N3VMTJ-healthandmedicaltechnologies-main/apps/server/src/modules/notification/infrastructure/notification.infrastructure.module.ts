import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationHospitalSubscriber } from './subscribers/notification.hospital.subscriber'

import { NotificationClinicSubscriber } from './subscribers/notification.clinic.subscriber'

import { NotificationDoctorSubscriber } from './subscribers/notification.doctor.subscriber'

import { NotificationAppointmentSubscriber } from './subscribers/notification.appointment.subscriber'

import { NotificationHospitaldoctorSubscriber } from './subscribers/notification.hospitaldoctor.subscriber'

import { NotificationClinicdoctorSubscriber } from './subscribers/notification.clinicdoctor.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationHospitalSubscriber,

    NotificationClinicSubscriber,

    NotificationDoctorSubscriber,

    NotificationAppointmentSubscriber,

    NotificationHospitaldoctorSubscriber,

    NotificationClinicdoctorSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
