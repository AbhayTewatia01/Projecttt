import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { HospitalApplicationModule } from './hospital/application'

import { ClinicApplicationModule } from './clinic/application'

import { DoctorApplicationModule } from './doctor/application'

import { AppointmentApplicationModule } from './appointment/application'

import { HospitaldoctorApplicationModule } from './hospitaldoctor/application'

import { ClinicdoctorApplicationModule } from './clinicdoctor/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,

    HospitalApplicationModule,

    ClinicApplicationModule,

    DoctorApplicationModule,

    AppointmentApplicationModule,

    HospitaldoctorApplicationModule,

    ClinicdoctorApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
