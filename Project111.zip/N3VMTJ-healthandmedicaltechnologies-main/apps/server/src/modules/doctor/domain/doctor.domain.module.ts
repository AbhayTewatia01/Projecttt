import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { DoctorDomainFacade } from './doctor.domain.facade'
import { Doctor } from './doctor.model'

@Module({
  imports: [TypeOrmModule.forFeature([Doctor]), DatabaseHelperModule],
  providers: [DoctorDomainFacade, DoctorDomainFacade],
  exports: [DoctorDomainFacade],
})
export class DoctorDomainModule {}
