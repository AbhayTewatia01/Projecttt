export * from './doctor.domain.facade'
export * from './doctor.domain.module'
export * from './doctor.model'
