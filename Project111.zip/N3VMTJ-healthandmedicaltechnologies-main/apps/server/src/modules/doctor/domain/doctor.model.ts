import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Appointment } from '../../../modules/appointment/domain'

import { Hospitaldoctor } from '../../../modules/hospitaldoctor/domain'

import { Clinicdoctor } from '../../../modules/clinicdoctor/domain'

@Entity()
export class Doctor {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  name: string

  @Column({})
  contactNumber: string

  @OneToMany(() => Appointment, child => child.doctor)
  appointments?: Appointment[]

  @OneToMany(() => Hospitaldoctor, child => child.doctor)
  hospitaldoctors?: Hospitaldoctor[]

  @OneToMany(() => Clinicdoctor, child => child.doctor)
  clinicdoctors?: Clinicdoctor[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
