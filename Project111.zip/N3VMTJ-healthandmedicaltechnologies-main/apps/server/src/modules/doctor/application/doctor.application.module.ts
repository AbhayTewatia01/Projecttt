import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { DoctorDomainModule } from '../domain'
import { DoctorController } from './doctor.controller'

@Module({
  imports: [AuthenticationDomainModule, DoctorDomainModule],
  controllers: [DoctorController],
  providers: [],
})
export class DoctorApplicationModule {}
