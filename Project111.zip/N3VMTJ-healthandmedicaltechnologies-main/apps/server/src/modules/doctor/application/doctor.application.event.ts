export namespace DoctorApplicationEvent {
  export namespace DoctorCreated {
    export const key = 'doctor.application.doctor.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
