import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Doctor, DoctorDomainFacade } from '@server/modules/doctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { DoctorApplicationEvent } from './doctor.application.event'
import { DoctorCreateDto, DoctorUpdateDto } from './doctor.dto'

@Controller('/v1/doctors')
export class DoctorController {
  constructor(
    private eventService: EventService,
    private doctorDomainFacade: DoctorDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.doctorDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: DoctorCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.doctorDomainFacade.create(body)

    await this.eventService.emit<DoctorApplicationEvent.DoctorCreated.Payload>(
      DoctorApplicationEvent.DoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:doctorId')
  async findOne(@Param('doctorId') doctorId: string, @Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.doctorDomainFacade.findOneByIdOrFail(
      doctorId,
      queryOptions,
    )

    return item
  }

  @Patch('/:doctorId')
  async update(
    @Param('doctorId') doctorId: string,
    @Body() body: DoctorUpdateDto,
  ) {
    const item = await this.doctorDomainFacade.findOneByIdOrFail(doctorId)

    const itemUpdated = await this.doctorDomainFacade.update(
      item,
      body as Partial<Doctor>,
    )
    return itemUpdated
  }

  @Delete('/:doctorId')
  async delete(@Param('doctorId') doctorId: string) {
    const item = await this.doctorDomainFacade.findOneByIdOrFail(doctorId)

    await this.doctorDomainFacade.delete(item)

    return item
  }
}
