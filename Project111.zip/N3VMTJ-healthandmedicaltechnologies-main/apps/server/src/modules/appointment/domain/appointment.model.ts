import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Doctor } from '../../../modules/doctor/domain'

@Entity()
export class Appointment {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  dateTime: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.appointments)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  doctorId: string

  @ManyToOne(() => Doctor, parent => parent.appointments)
  @JoinColumn({ name: 'doctorId' })
  doctor?: Doctor

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
