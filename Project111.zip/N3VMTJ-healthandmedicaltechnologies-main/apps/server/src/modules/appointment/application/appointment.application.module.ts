import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { AppointmentDomainModule } from '../domain'
import { AppointmentController } from './appointment.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { AppointmentByUserController } from './appointmentByUser.controller'

import { DoctorDomainModule } from '../../../modules/doctor/domain'

import { AppointmentByDoctorController } from './appointmentByDoctor.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    AppointmentDomainModule,

    UserDomainModule,

    DoctorDomainModule,
  ],
  controllers: [
    AppointmentController,

    AppointmentByUserController,

    AppointmentByDoctorController,
  ],
  providers: [],
})
export class AppointmentApplicationModule {}
