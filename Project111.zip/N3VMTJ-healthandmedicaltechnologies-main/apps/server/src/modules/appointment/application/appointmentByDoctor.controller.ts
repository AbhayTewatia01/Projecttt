import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { AppointmentDomainFacade } from '@server/modules/appointment/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { AppointmentApplicationEvent } from './appointment.application.event'
import { AppointmentCreateDto } from './appointment.dto'

import { DoctorDomainFacade } from '../../doctor/domain'

@Controller('/v1/doctors')
export class AppointmentByDoctorController {
  constructor(
    private doctorDomainFacade: DoctorDomainFacade,

    private appointmentDomainFacade: AppointmentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/doctor/:doctorId/appointments')
  async findManyDoctorId(
    @Param('doctorId') doctorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.doctorDomainFacade.findOneByIdOrFail(doctorId)

    const items = await this.appointmentDomainFacade.findManyByDoctor(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/doctor/:doctorId/appointments')
  async createByDoctorId(
    @Param('doctorId') doctorId: string,
    @Body() body: AppointmentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, doctorId }

    const item = await this.appointmentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<AppointmentApplicationEvent.AppointmentCreated.Payload>(
      AppointmentApplicationEvent.AppointmentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
