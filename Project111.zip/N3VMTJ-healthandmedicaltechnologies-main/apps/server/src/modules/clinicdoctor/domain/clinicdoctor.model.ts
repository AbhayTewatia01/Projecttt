import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Clinic } from '../../../modules/clinic/domain'

import { Doctor } from '../../../modules/doctor/domain'

@Entity()
export class Clinicdoctor {
  @Column({})
  clinicId: string

  @ManyToOne(() => Clinic, parent => parent.clinicdoctors)
  @JoinColumn({ name: 'clinicId' })
  clinic?: Clinic

  @Column({})
  doctorId: string

  @ManyToOne(() => Doctor, parent => parent.clinicdoctors)
  @JoinColumn({ name: 'doctorId' })
  doctor?: Doctor

  @PrimaryGeneratedColumn('uuid')
  id: string

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
