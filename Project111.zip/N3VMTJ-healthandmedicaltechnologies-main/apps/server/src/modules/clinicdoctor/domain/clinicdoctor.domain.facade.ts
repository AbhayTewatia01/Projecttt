import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Clinicdoctor } from './clinicdoctor.model'

import { Clinic } from '../../clinic/domain'

import { Doctor } from '../../doctor/domain'

@Injectable()
export class ClinicdoctorDomainFacade {
  constructor(
    @InjectRepository(Clinicdoctor)
    private repository: Repository<Clinicdoctor>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<Clinicdoctor>): Promise<Clinicdoctor> {
    return this.repository.save(values)
  }

  async update(
    item: Clinicdoctor,
    values: Partial<Clinicdoctor>,
  ): Promise<Clinicdoctor> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Clinicdoctor): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Clinicdoctor> = {},
  ): Promise<Clinicdoctor[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Clinicdoctor> = {},
  ): Promise<Clinicdoctor> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByClinic(
    item: Clinic,
    queryOptions: RequestHelper.QueryOptions<Clinicdoctor> = {},
  ): Promise<Clinicdoctor[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('clinic')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        clinicId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByDoctor(
    item: Doctor,
    queryOptions: RequestHelper.QueryOptions<Clinicdoctor> = {},
  ): Promise<Clinicdoctor[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('doctor')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        doctorId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
