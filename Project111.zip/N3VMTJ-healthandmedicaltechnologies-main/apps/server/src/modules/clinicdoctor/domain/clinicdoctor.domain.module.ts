import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ClinicdoctorDomainFacade } from './clinicdoctor.domain.facade'
import { Clinicdoctor } from './clinicdoctor.model'

@Module({
  imports: [TypeOrmModule.forFeature([Clinicdoctor]), DatabaseHelperModule],
  providers: [ClinicdoctorDomainFacade, ClinicdoctorDomainFacade],
  exports: [ClinicdoctorDomainFacade],
})
export class ClinicdoctorDomainModule {}
