import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ClinicdoctorCreateDto {
  @IsString()
  @IsOptional()
  clinicId?: string

  @IsString()
  @IsOptional()
  doctorId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ClinicdoctorUpdateDto {
  @IsString()
  @IsOptional()
  clinicId?: string

  @IsString()
  @IsOptional()
  doctorId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
