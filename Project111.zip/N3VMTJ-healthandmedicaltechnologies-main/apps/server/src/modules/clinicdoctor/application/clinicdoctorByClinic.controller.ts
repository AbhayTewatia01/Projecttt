import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ClinicdoctorDomainFacade } from '@server/modules/clinicdoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ClinicdoctorApplicationEvent } from './clinicdoctor.application.event'
import { ClinicdoctorCreateDto } from './clinicdoctor.dto'

import { ClinicDomainFacade } from '../../clinic/domain'

@Controller('/v1/clinics')
export class ClinicdoctorByClinicController {
  constructor(
    private clinicDomainFacade: ClinicDomainFacade,

    private clinicdoctorDomainFacade: ClinicdoctorDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/clinic/:clinicId/clinicdoctors')
  async findManyClinicId(
    @Param('clinicId') clinicId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.clinicDomainFacade.findOneByIdOrFail(clinicId)

    const items = await this.clinicdoctorDomainFacade.findManyByClinic(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/clinic/:clinicId/clinicdoctors')
  async createByClinicId(
    @Param('clinicId') clinicId: string,
    @Body() body: ClinicdoctorCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, clinicId }

    const item = await this.clinicdoctorDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClinicdoctorApplicationEvent.ClinicdoctorCreated.Payload>(
      ClinicdoctorApplicationEvent.ClinicdoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
