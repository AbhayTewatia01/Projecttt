import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ClinicdoctorDomainModule } from '../domain'
import { ClinicdoctorController } from './clinicdoctor.controller'

import { ClinicDomainModule } from '../../../modules/clinic/domain'

import { ClinicdoctorByClinicController } from './clinicdoctorByClinic.controller'

import { DoctorDomainModule } from '../../../modules/doctor/domain'

import { ClinicdoctorByDoctorController } from './clinicdoctorByDoctor.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ClinicdoctorDomainModule,

    ClinicDomainModule,

    DoctorDomainModule,
  ],
  controllers: [
    ClinicdoctorController,

    ClinicdoctorByClinicController,

    ClinicdoctorByDoctorController,
  ],
  providers: [],
})
export class ClinicdoctorApplicationModule {}
