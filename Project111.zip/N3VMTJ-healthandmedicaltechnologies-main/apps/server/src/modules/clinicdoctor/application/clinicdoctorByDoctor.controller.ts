import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ClinicdoctorDomainFacade } from '@server/modules/clinicdoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ClinicdoctorApplicationEvent } from './clinicdoctor.application.event'
import { ClinicdoctorCreateDto } from './clinicdoctor.dto'

import { DoctorDomainFacade } from '../../doctor/domain'

@Controller('/v1/doctors')
export class ClinicdoctorByDoctorController {
  constructor(
    private doctorDomainFacade: DoctorDomainFacade,

    private clinicdoctorDomainFacade: ClinicdoctorDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/doctor/:doctorId/clinicdoctors')
  async findManyDoctorId(
    @Param('doctorId') doctorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.doctorDomainFacade.findOneByIdOrFail(doctorId)

    const items = await this.clinicdoctorDomainFacade.findManyByDoctor(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/doctor/:doctorId/clinicdoctors')
  async createByDoctorId(
    @Param('doctorId') doctorId: string,
    @Body() body: ClinicdoctorCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, doctorId }

    const item = await this.clinicdoctorDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClinicdoctorApplicationEvent.ClinicdoctorCreated.Payload>(
      ClinicdoctorApplicationEvent.ClinicdoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
