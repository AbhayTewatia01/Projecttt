import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  Clinicdoctor,
  ClinicdoctorDomainFacade,
} from '@server/modules/clinicdoctor/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ClinicdoctorApplicationEvent } from './clinicdoctor.application.event'
import {
  ClinicdoctorCreateDto,
  ClinicdoctorUpdateDto,
} from './clinicdoctor.dto'

@Controller('/v1/clinicdoctors')
export class ClinicdoctorController {
  constructor(
    private eventService: EventService,
    private clinicdoctorDomainFacade: ClinicdoctorDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.clinicdoctorDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ClinicdoctorCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.clinicdoctorDomainFacade.create(body)

    await this.eventService.emit<ClinicdoctorApplicationEvent.ClinicdoctorCreated.Payload>(
      ClinicdoctorApplicationEvent.ClinicdoctorCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:clinicdoctorId')
  async findOne(
    @Param('clinicdoctorId') clinicdoctorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.clinicdoctorDomainFacade.findOneByIdOrFail(
      clinicdoctorId,
      queryOptions,
    )

    return item
  }

  @Patch('/:clinicdoctorId')
  async update(
    @Param('clinicdoctorId') clinicdoctorId: string,
    @Body() body: ClinicdoctorUpdateDto,
  ) {
    const item =
      await this.clinicdoctorDomainFacade.findOneByIdOrFail(clinicdoctorId)

    const itemUpdated = await this.clinicdoctorDomainFacade.update(
      item,
      body as Partial<Clinicdoctor>,
    )
    return itemUpdated
  }

  @Delete('/:clinicdoctorId')
  async delete(@Param('clinicdoctorId') clinicdoctorId: string) {
    const item =
      await this.clinicdoctorDomainFacade.findOneByIdOrFail(clinicdoctorId)

    await this.clinicdoctorDomainFacade.delete(item)

    return item
  }
}
