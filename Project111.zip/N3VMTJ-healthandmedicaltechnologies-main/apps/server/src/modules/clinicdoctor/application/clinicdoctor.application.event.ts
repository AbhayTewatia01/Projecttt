export namespace ClinicdoctorApplicationEvent {
  export namespace ClinicdoctorCreated {
    export const key = 'clinicdoctor.application.clinicdoctor.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
