import { Hospital } from '../hospital'

import { Doctor } from '../doctor'

export class Hospitaldoctor {
  hospitalId: string

  hospital?: Hospital

  doctorId: string

  doctor?: Doctor

  id: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
