import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Hospitaldoctor } from './hospitaldoctor.model'

export class HospitaldoctorApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Hospitaldoctor>,
  ): Promise<Hospitaldoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hospitaldoctors${buildOptions}`)
  }

  static findOne(
    hospitaldoctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Hospitaldoctor>,
  ): Promise<Hospitaldoctor> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/hospitaldoctors/${hospitaldoctorId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<Hospitaldoctor>): Promise<Hospitaldoctor> {
    return HttpService.api.post(`/v1/hospitaldoctors`, values)
  }

  static updateOne(
    hospitaldoctorId: string,
    values: Partial<Hospitaldoctor>,
  ): Promise<Hospitaldoctor> {
    return HttpService.api.patch(
      `/v1/hospitaldoctors/${hospitaldoctorId}`,
      values,
    )
  }

  static deleteOne(hospitaldoctorId: string): Promise<void> {
    return HttpService.api.delete(`/v1/hospitaldoctors/${hospitaldoctorId}`)
  }

  static findManyByHospitalId(
    hospitalId: string,
    queryOptions?: ApiHelper.QueryOptions<Hospitaldoctor>,
  ): Promise<Hospitaldoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/hospitals/hospital/${hospitalId}/hospitaldoctors${buildOptions}`,
    )
  }

  static createOneByHospitalId(
    hospitalId: string,
    values: Partial<Hospitaldoctor>,
  ): Promise<Hospitaldoctor> {
    return HttpService.api.post(
      `/v1/hospitals/hospital/${hospitalId}/hospitaldoctors`,
      values,
    )
  }

  static findManyByDoctorId(
    doctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Hospitaldoctor>,
  ): Promise<Hospitaldoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/doctors/doctor/${doctorId}/hospitaldoctors${buildOptions}`,
    )
  }

  static createOneByDoctorId(
    doctorId: string,
    values: Partial<Hospitaldoctor>,
  ): Promise<Hospitaldoctor> {
    return HttpService.api.post(
      `/v1/doctors/doctor/${doctorId}/hospitaldoctors`,
      values,
    )
  }
}
