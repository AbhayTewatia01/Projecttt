import { Clinicdoctor } from '../clinicdoctor'

export class Clinic {
  id: string

  name: string

  address: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  clinicdoctors?: Clinicdoctor[]
}
