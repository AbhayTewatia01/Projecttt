import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Clinic } from './clinic.model'

export class ClinicApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Clinic>,
  ): Promise<Clinic[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/clinics${buildOptions}`)
  }

  static findOne(
    clinicId: string,
    queryOptions?: ApiHelper.QueryOptions<Clinic>,
  ): Promise<Clinic> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/clinics/${clinicId}${buildOptions}`)
  }

  static createOne(values: Partial<Clinic>): Promise<Clinic> {
    return HttpService.api.post(`/v1/clinics`, values)
  }

  static updateOne(clinicId: string, values: Partial<Clinic>): Promise<Clinic> {
    return HttpService.api.patch(`/v1/clinics/${clinicId}`, values)
  }

  static deleteOne(clinicId: string): Promise<void> {
    return HttpService.api.delete(`/v1/clinics/${clinicId}`)
  }
}
