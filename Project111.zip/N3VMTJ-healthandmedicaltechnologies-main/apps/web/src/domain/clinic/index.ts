export * from './clinic.api'
export * from './clinic.model'
