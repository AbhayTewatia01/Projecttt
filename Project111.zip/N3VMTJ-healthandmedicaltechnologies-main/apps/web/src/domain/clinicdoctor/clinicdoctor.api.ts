import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Clinicdoctor } from './clinicdoctor.model'

export class ClinicdoctorApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Clinicdoctor>,
  ): Promise<Clinicdoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/clinicdoctors${buildOptions}`)
  }

  static findOne(
    clinicdoctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Clinicdoctor>,
  ): Promise<Clinicdoctor> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/clinicdoctors/${clinicdoctorId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<Clinicdoctor>): Promise<Clinicdoctor> {
    return HttpService.api.post(`/v1/clinicdoctors`, values)
  }

  static updateOne(
    clinicdoctorId: string,
    values: Partial<Clinicdoctor>,
  ): Promise<Clinicdoctor> {
    return HttpService.api.patch(`/v1/clinicdoctors/${clinicdoctorId}`, values)
  }

  static deleteOne(clinicdoctorId: string): Promise<void> {
    return HttpService.api.delete(`/v1/clinicdoctors/${clinicdoctorId}`)
  }

  static findManyByClinicId(
    clinicId: string,
    queryOptions?: ApiHelper.QueryOptions<Clinicdoctor>,
  ): Promise<Clinicdoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/clinics/clinic/${clinicId}/clinicdoctors${buildOptions}`,
    )
  }

  static createOneByClinicId(
    clinicId: string,
    values: Partial<Clinicdoctor>,
  ): Promise<Clinicdoctor> {
    return HttpService.api.post(
      `/v1/clinics/clinic/${clinicId}/clinicdoctors`,
      values,
    )
  }

  static findManyByDoctorId(
    doctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Clinicdoctor>,
  ): Promise<Clinicdoctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/doctors/doctor/${doctorId}/clinicdoctors${buildOptions}`,
    )
  }

  static createOneByDoctorId(
    doctorId: string,
    values: Partial<Clinicdoctor>,
  ): Promise<Clinicdoctor> {
    return HttpService.api.post(
      `/v1/doctors/doctor/${doctorId}/clinicdoctors`,
      values,
    )
  }
}
