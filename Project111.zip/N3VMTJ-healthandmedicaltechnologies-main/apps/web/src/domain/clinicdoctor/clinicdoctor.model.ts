import { Clinic } from '../clinic'

import { Doctor } from '../doctor'

export class Clinicdoctor {
  clinicId: string

  clinic?: Clinic

  doctorId: string

  doctor?: Doctor

  id: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
