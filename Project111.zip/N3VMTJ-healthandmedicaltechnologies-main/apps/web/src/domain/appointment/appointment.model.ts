import { User } from '../user'

import { Doctor } from '../doctor'

export class Appointment {
  id: string

  dateTime: string

  userId: string

  user?: User

  doctorId: string

  doctor?: Doctor

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
