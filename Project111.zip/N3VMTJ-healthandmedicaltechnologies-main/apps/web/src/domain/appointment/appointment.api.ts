import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Appointment } from './appointment.model'

export class AppointmentApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Appointment>,
  ): Promise<Appointment[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/appointments${buildOptions}`)
  }

  static findOne(
    appointmentId: string,
    queryOptions?: ApiHelper.QueryOptions<Appointment>,
  ): Promise<Appointment> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/appointments/${appointmentId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<Appointment>): Promise<Appointment> {
    return HttpService.api.post(`/v1/appointments`, values)
  }

  static updateOne(
    appointmentId: string,
    values: Partial<Appointment>,
  ): Promise<Appointment> {
    return HttpService.api.patch(`/v1/appointments/${appointmentId}`, values)
  }

  static deleteOne(appointmentId: string): Promise<void> {
    return HttpService.api.delete(`/v1/appointments/${appointmentId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Appointment>,
  ): Promise<Appointment[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/appointments${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Appointment>,
  ): Promise<Appointment> {
    return HttpService.api.post(`/v1/users/user/${userId}/appointments`, values)
  }

  static findManyByDoctorId(
    doctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Appointment>,
  ): Promise<Appointment[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/doctors/doctor/${doctorId}/appointments${buildOptions}`,
    )
  }

  static createOneByDoctorId(
    doctorId: string,
    values: Partial<Appointment>,
  ): Promise<Appointment> {
    return HttpService.api.post(
      `/v1/doctors/doctor/${doctorId}/appointments`,
      values,
    )
  }
}
