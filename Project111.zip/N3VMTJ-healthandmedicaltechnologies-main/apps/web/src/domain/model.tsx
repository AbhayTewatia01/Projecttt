import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Hospital as HospitalModel } from './hospital/hospital.model'

import { Clinic as ClinicModel } from './clinic/clinic.model'

import { Doctor as DoctorModel } from './doctor/doctor.model'

import { Appointment as AppointmentModel } from './appointment/appointment.model'

import { Hospitaldoctor as HospitaldoctorModel } from './hospitaldoctor/hospitaldoctor.model'

import { Clinicdoctor as ClinicdoctorModel } from './clinicdoctor/clinicdoctor.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Hospital extends HospitalModel {}

  export class Clinic extends ClinicModel {}

  export class Doctor extends DoctorModel {}

  export class Appointment extends AppointmentModel {}

  export class Hospitaldoctor extends HospitaldoctorModel {}

  export class Clinicdoctor extends ClinicdoctorModel {}
}
