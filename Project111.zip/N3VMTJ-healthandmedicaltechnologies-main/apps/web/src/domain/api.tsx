import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { HospitalApi } from './hospital/hospital.api'

import { ClinicApi } from './clinic/clinic.api'

import { DoctorApi } from './doctor/doctor.api'

import { AppointmentApi } from './appointment/appointment.api'

import { HospitaldoctorApi } from './hospitaldoctor/hospitaldoctor.api'

import { ClinicdoctorApi } from './clinicdoctor/clinicdoctor.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Hospital extends HospitalApi {}

  export class Clinic extends ClinicApi {}

  export class Doctor extends DoctorApi {}

  export class Appointment extends AppointmentApi {}

  export class Hospitaldoctor extends HospitaldoctorApi {}

  export class Clinicdoctor extends ClinicdoctorApi {}
}
