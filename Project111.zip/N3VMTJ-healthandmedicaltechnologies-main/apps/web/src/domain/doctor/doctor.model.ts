import { Appointment } from '../appointment'

import { Hospitaldoctor } from '../hospitaldoctor'

import { Clinicdoctor } from '../clinicdoctor'

export class Doctor {
  id: string

  name: string

  contactNumber: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  appointments?: Appointment[]

  hospitaldoctors?: Hospitaldoctor[]

  clinicdoctors?: Clinicdoctor[]
}
