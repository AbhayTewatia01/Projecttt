import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Doctor } from './doctor.model'

export class DoctorApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Doctor>,
  ): Promise<Doctor[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/doctors${buildOptions}`)
  }

  static findOne(
    doctorId: string,
    queryOptions?: ApiHelper.QueryOptions<Doctor>,
  ): Promise<Doctor> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/doctors/${doctorId}${buildOptions}`)
  }

  static createOne(values: Partial<Doctor>): Promise<Doctor> {
    return HttpService.api.post(`/v1/doctors`, values)
  }

  static updateOne(doctorId: string, values: Partial<Doctor>): Promise<Doctor> {
    return HttpService.api.patch(`/v1/doctors/${doctorId}`, values)
  }

  static deleteOne(doctorId: string): Promise<void> {
    return HttpService.api.delete(`/v1/doctors/${doctorId}`)
  }
}
