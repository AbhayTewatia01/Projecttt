export * from './hospital.api'
export * from './hospital.model'
