import { Hospitaldoctor } from '../hospitaldoctor'

export class Hospital {
  id: string

  name: string

  address: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  hospitaldoctors?: Hospitaldoctor[]
}
