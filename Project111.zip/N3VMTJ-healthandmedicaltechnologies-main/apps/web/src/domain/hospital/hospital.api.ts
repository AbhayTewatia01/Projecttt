import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Hospital } from './hospital.model'

export class HospitalApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Hospital>,
  ): Promise<Hospital[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hospitals${buildOptions}`)
  }

  static findOne(
    hospitalId: string,
    queryOptions?: ApiHelper.QueryOptions<Hospital>,
  ): Promise<Hospital> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/hospitals/${hospitalId}${buildOptions}`)
  }

  static createOne(values: Partial<Hospital>): Promise<Hospital> {
    return HttpService.api.post(`/v1/hospitals`, values)
  }

  static updateOne(
    hospitalId: string,
    values: Partial<Hospital>,
  ): Promise<Hospital> {
    return HttpService.api.patch(`/v1/hospitals/${hospitalId}`, values)
  }

  static deleteOne(hospitalId: string): Promise<void> {
    return HttpService.api.delete(`/v1/hospitals/${hospitalId}`)
  }
}
