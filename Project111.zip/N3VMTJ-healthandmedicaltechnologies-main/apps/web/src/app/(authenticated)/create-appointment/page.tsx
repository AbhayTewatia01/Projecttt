'use client'

import { useEffect, useState } from 'react'
import { Button, DatePicker, Select, Typography } from 'antd'
import {
  UserOutlined,
  CalendarOutlined,
  HomeOutlined,
  PlusCircleOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function CreateAppointmentPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [hospitals, setHospitals] = useState([])
  const [clinics, setClinics] = useState([])
  const [doctors, setDoctors] = useState([])
  const [selectedDoctor, setSelectedDoctor] = useState('')
  const [selectedDate, setSelectedDate] = useState('')

  useEffect(() => {
    const fetchHospitalsAndClinics = async () => {
      try {
        const hospitalsFound = await Api.Hospital.findMany({
          includes: ['hospitaldoctors', 'hospitaldoctors.doctor'],
        })
        const clinicsFound = await Api.Clinic.findMany({
          includes: ['clinicdoctors', 'clinicdoctors.doctor'],
        })
        setHospitals(hospitalsFound)
        setClinics(clinicsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch hospitals and clinics', {
          variant: 'error',
        })
      }
    }

    const fetchDoctors = async () => {
      try {
        const doctorsFound = await Api.Doctor.findMany({
          includes: ['hospitaldoctors', 'clinicdoctors'],
        })
        setDoctors(doctorsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch doctors', { variant: 'error' })
      }
    }

    fetchHospitalsAndClinics()
    fetchDoctors()
  }, [])

  const handleDateChange = (date, dateString) => {
    setSelectedDate(dateString)
  }

  const handleDoctorChange = value => {
    setSelectedDoctor(value)
  }

  const handleSubmit = async () => {
    if (!selectedDate || !selectedDoctor) {
      enqueueSnackbar('Please select both a doctor and a date', {
        variant: 'info',
      })
      return
    }

    try {
      const appointment = await Api.Appointment.createOneByUserId(userId, {
        dateTime: selectedDate,
        doctorId: selectedDoctor,
      })
      enqueueSnackbar('Appointment created successfully', {
        variant: 'success',
      })
      router.push('/appointments')
    } catch (error) {
      enqueueSnackbar('Failed to create appointment', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CalendarOutlined /> Create an Appointment
      </Title>
      <Text>Select a doctor and choose a date to book your appointment.</Text>

      <Select
        style={{ width: '100%', marginTop: 20 }}
        placeholder="Select a doctor"
        onChange={handleDoctorChange}
        suffixIcon={<UserOutlined />}
      >
        {doctors?.map(doctor => (
          <Option key={doctor.id} value={doctor.id}>
            {doctor.name}
          </Option>
        ))}
      </Select>

      <DatePicker
        style={{ width: '100%', marginTop: 20 }}
        onChange={handleDateChange}
        suffixIcon={<HomeOutlined />}
      />

      <Button
        type="primary"
        style={{ marginTop: 20 }}
        onClick={handleSubmit}
        icon={<PlusCircleOutlined />}
      >
        Book Appointment
      </Button>
    </PageLayout>
  )
}
