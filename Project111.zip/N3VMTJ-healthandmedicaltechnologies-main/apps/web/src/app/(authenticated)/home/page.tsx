'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Col, Row, Button, Avatar } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [user, setUser] = useState(null)

  useEffect(() => {
    if (userId) {
      Api.User.findOne(userId, { includes: ['appointments', 'notifications'] })
        .then(setUser)
        .catch(() => {
          enqueueSnackbar('Failed to fetch user data', { variant: 'error' })
        })
    }
  }, [userId])

  const navigateTo = path => {
    router.push(path)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Welcome to Your Dashboard</Title>
      <Text>Welcome back, {user?.name || 'User'}!</Text>
      <Row gutter={16} style={{ marginTop: 20 }}>
        <Col span={8}>
          <Card
            title="Appointments"
            actions={[
              <Button
                type="primary"
                onClick={() => navigateTo('/appointments')}
              >
                View Appointments
              </Button>,
            ]}
          >
            <p>
              You have {user?.appointments?.length || 0} upcoming appointments.
            </p>
          </Card>
        </Col>
        <Col span={8}>
          <Card
            title="Notifications"
            actions={[
              <Button
                type="primary"
                onClick={() => navigateTo('/notifications')}
              >
                View Notifications
              </Button>,
            ]}
          >
            <p>
              You have {user?.notifications?.length || 0} new notifications.
            </p>
          </Card>
        </Col>
        <Col span={8}>
          <Card
            title="Profile"
            actions={[
              <Button type="primary" onClick={() => navigateTo('/profile')}>
                View Profile
              </Button>,
            ]}
          >
            <Avatar src={user?.pictureUrl || UserOutlined} />
            <p>Email: {user?.email}</p>
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
