'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Avatar, Space, Button } from 'antd'
import { PhoneOutlined, MailOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
interface Doctor extends Model.Doctor {}
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ListofDoctorsPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const [doctors, setDoctors] = useState<Doctor[]>([])

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const doctorsFound = await Api.Doctor.findMany({
          includes: ['clinicdoctors', 'hospitaldoctors'],
        })
        setDoctors(doctorsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch doctors', { variant: 'error' })
      }
    }

    fetchDoctors()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>List of Doctors</Title>
      <Text type="secondary">
        Here you can find contact details for all our registered doctors.
      </Text>
      <List
        itemLayout="horizontal"
        dataSource={doctors}
        renderItem={doctor => (
          <List.Item
            actions={[
              <Button
                type="link"
                icon={<PhoneOutlined />}
                onClick={() =>
                  (window.location.href = `tel:${doctor.contactNumber}`)
                }
              >
                Call
              </Button>,
            ]}
          >
            <List.Item.Meta
              avatar={<Avatar src="https://via.placeholder.com/150" />}
              title={
                <a onClick={() => router.push(`/doctor/${doctor.id}`)}>
                  {doctor.name}
                </a>
              }
              description={`Joined on ${dayjs(doctor.dateCreated).format('MMMM D, YYYY')}`}
            />
          </List.Item>
        )}
      />
    </PageLayout>
  )
}
