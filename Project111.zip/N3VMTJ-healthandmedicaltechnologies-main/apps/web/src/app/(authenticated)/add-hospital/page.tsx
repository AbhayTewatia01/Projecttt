'use client'

import { useState } from 'react'
import { Button, Form, Input, Typography } from 'antd'
import { PlusCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function AddHospitalPage() {
  const [form] = Form.useForm()
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const handleSubmit = async (values: { name: string; address: string }) => {
    try {
      await Api.Hospital.createOne(values)
      enqueueSnackbar('Hospital added successfully!', { variant: 'success' })
      router.push('/nearby-hospitals-clinics')
    } catch (error) {
      enqueueSnackbar('Failed to add hospital. Please try again.', {
        variant: 'error',
      })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <PlusCircleOutlined /> Add New Hospital
      </Title>
      <Text type="secondary">
        Enter the details of the new hospital to add it to the database.
      </Text>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        style={{ marginTop: '20px' }}
      >
        <Form.Item
          label="Hospital Name"
          name="name"
          rules={[
            { required: true, message: 'Please input the hospital name!' },
          ]}
        >
          <Input placeholder="Enter hospital name" />
        </Form.Item>
        <Form.Item
          label="Address"
          name="address"
          rules={[{ required: true, message: 'Please input the address!' }]}
        >
          <Input placeholder="Enter address" />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Add Hospital
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
