'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, List, Avatar } from 'antd'
import { EnvironmentOutlined, UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HospitalDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { enqueueSnackbar } = useSnackbar()
  const [hospital, setHospital] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchHospitalDetails = async () => {
      try {
        const hospitalDetails = await Api.Hospital.findOne(params.id, {
          includes: ['hospitaldoctors', 'hospitaldoctors.doctor'],
        })
        setHospital(hospitalDetails)
      } catch (error) {
        enqueueSnackbar('Failed to fetch hospital details', {
          variant: 'error',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchHospitalDetails()
  }, [params.id])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Hospital Details</Title>
      {loading ? (
        <Text>Loading...</Text>
      ) : hospital ? (
        <>
          <Card
            style={{ marginBottom: 20 }}
            actions={[
              <EnvironmentOutlined key="address" />,
              <Text key="addressText">{hospital.address}</Text>,
            ]}
          >
            <Card.Meta
              avatar={<Avatar icon={<UserOutlined />} />}
              title={hospital.name}
              description={`Established: ${dayjs(hospital.dateCreated).format('DD MMM YYYY')}`}
            />
          </Card>
          <Title level={4}>Associated Doctors</Title>
          <List
            itemLayout="horizontal"
            dataSource={hospital.hospitaldoctors?.map(hd => hd.doctor)}
            renderItem={doctor => (
              <List.Item>
                <List.Item.Meta
                  avatar={
                    <Avatar
                      src={doctor.pictureUrl || undefined}
                      icon={<UserOutlined />}
                    />
                  }
                  title={
                    <a onClick={() => router.push(`/doctor/${doctor.id}`)}>
                      {doctor.name}
                    </a>
                  }
                  description={`Contact: ${doctor.contactNumber}`}
                />
              </List.Item>
            )}
          />
        </>
      ) : (
        <Text>No hospital details available.</Text>
      )}
    </PageLayout>
  )
}
