'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Card, List, Avatar, Space } from 'antd'
import {
  PhoneOutlined,
  HomeOutlined,
  MailOutlined,
  HomeOutlined as HospitalOutlined,
  CiOutlined as ClinicOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function DoctorDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { enqueueSnackbar } = useSnackbar()
  const [doctor, setDoctor] = useState<Model.Doctor | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchDoctorDetails = async () => {
      try {
        const fetchedDoctor = await Api.Doctor.findOne(params.id, {
          includes: ['hospitaldoctors.hospital', 'clinicdoctors.clinic'],
        })
        setDoctor(fetchedDoctor)
      } catch (error) {
        enqueueSnackbar('Failed to fetch doctor details', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchDoctorDetails()
  }, [params.id])

  if (loading) {
    return <PageLayout layout="narrow">Loading...</PageLayout>
  }

  if (!doctor) {
    return <PageLayout layout="narrow">Doctor not found.</PageLayout>
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Doctor Details</Title>
      <Card>
        <List.Item>
          <List.Item.Meta
            avatar={<Avatar src={undefined} />} // Removed doctor.pictureUrl as it's not part of the Doctor model
            title={doctor.name}
            description={
              <Space direction="vertical">
                <Text>
                  <PhoneOutlined /> {doctor.contactNumber}
                </Text>
                {/* Removed Email as it's not part of the Doctor model */}
              </Space>
            }
          />
        </List.Item>
        <List
          header={<div>Associated Hospitals</div>}
          bordered
          dataSource={doctor.hospitaldoctors?.map(hd => hd.hospital)}
          renderItem={item => (
            <List.Item>
              <List.Item.Meta
                avatar={<HospitalOutlined />}
                title={item.name}
                description={item.address}
              />
            </List.Item>
          )}
        />
        <List
          header={<div>Associated Clinics</div>}
          bordered
          dataSource={doctor.clinicdoctors?.map(cd => cd.clinic)}
          renderItem={item => (
            <List.Item>
              <List.Item.Meta
                avatar={<ClinicOutlined />}
                title={item.name}
                description={item.address}
              />
            </List.Item>
          )}
        />
      </Card>
    </PageLayout>
  )
}
