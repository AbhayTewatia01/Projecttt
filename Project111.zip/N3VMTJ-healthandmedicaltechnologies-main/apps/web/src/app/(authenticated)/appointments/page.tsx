'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Avatar, Button, Space } from 'antd'
import { CalendarOutlined, UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ListofAppointmentsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [appointments, setAppointments] = useState([])

  useEffect(() => {
    if (userId) {
      Api.Appointment.findManyByUserId(userId, { includes: ['doctor'] })
        .then(setAppointments)
        .catch(() =>
          enqueueSnackbar('Failed to fetch appointments', { variant: 'error' }),
        )
    }
  }, [userId])

  const handleAppointmentClick = appointmentId => {
    router.push(`/appointment/${appointmentId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Your Appointments</Title>
      <Text type="secondary">
        Here you can view and manage all your scheduled appointments.
      </Text>
      <List
        itemLayout="horizontal"
        dataSource={appointments}
        renderItem={appointment => (
          <List.Item
            actions={[
              <Button
                type="link"
                onClick={() => handleAppointmentClick(appointment.id)}
              >
                View Details
              </Button>,
            ]}
          >
            <List.Item.Meta
              avatar={
                <Avatar
                  icon={<UserOutlined />}
                  src={appointment.doctor?.pictureUrl}
                />
              }
              title={appointment.doctor?.name}
              description={
                <Space>
                  <CalendarOutlined />
                  {dayjs(appointment.dateTime).format(
                    'dddd, MMMM D, YYYY h:mm A',
                  )}
                </Space>
              }
            />
          </List.Item>
        )}
      />
    </PageLayout>
  )
}
