'use client'

import React, { useState } from 'react'
import { Button, Form, Input, Typography } from 'antd'
import { PlusCircleOutlined } from '@ant-design/icons'
const { Title, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function AddClinicPage() {
  const [form] = Form.useForm()
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const handleSubmit = async (values: { name: string; address: string }) => {
    try {
      await Api.Clinic.createOne(values)
      enqueueSnackbar('Clinic added successfully', { variant: 'success' })
      router.push('/nearby-hospitals-clinics')
    } catch (error) {
      enqueueSnackbar('Failed to add clinic', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Add New Clinic</Title>
      <Paragraph>
        Enter the details of the new clinic you want to add to the system.
      </Paragraph>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        requiredMark={false}
      >
        <Form.Item
          name="name"
          label="Clinic Name"
          rules={[{ required: true, message: 'Please input the clinic name!' }]}
        >
          <Input placeholder="Enter clinic name" />
        </Form.Item>
        <Form.Item
          name="address"
          label="Address"
          rules={[{ required: true, message: 'Please input the address!' }]}
        >
          <Input placeholder="Enter address" />
        </Form.Item>
        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            icon={<PlusCircleOutlined />}
          >
            Add Clinic
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
