'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Card, Avatar, Spin } from 'antd'
import { EnvironmentOutlined, PhoneOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function NearbyHospitalsandClinicsPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()

  const [hospitals, setHospitals] = useState([])
  const [clinics, setClinics] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const hospitalsData = await Api.Hospital.findMany({
          includes: ['hospitaldoctors', 'hospitaldoctors.doctor'],
        })
        const clinicsData = await Api.Clinic.findMany({
          includes: ['clinicdoctors', 'clinicdoctors.doctor'],
        })
        setHospitals(hospitalsData)
        setClinics(clinicsData)
      } catch (error) {
        enqueueSnackbar('Failed to fetch data', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleHospitalClick = id => {
    router.push(`/hospital/${id}`)
  }

  const handleClinicClick = id => {
    router.push(`/clinic/${id}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Nearby Hospitals and Clinics</Title>
      <Text>Find health facilities in your vicinity.</Text>
      {loading ? (
        <Spin size="large" />
      ) : (
        <>
          <Title level={4}>Hospitals</Title>
          <List
            itemLayout="horizontal"
            dataSource={hospitals}
            renderItem={hospital => (
              <List.Item onClick={() => handleHospitalClick(hospital.id)}>
                <Card hoverable>
                  <Card.Meta
                    avatar={<Avatar icon={<EnvironmentOutlined />} />}
                    title={hospital.name}
                    description={hospital.address}
                  />
                </Card>
              </List.Item>
            )}
          />
          <Title level={4}>Clinics</Title>
          <List
            itemLayout="horizontal"
            dataSource={clinics}
            renderItem={clinic => (
              <List.Item onClick={() => handleClinicClick(clinic.id)}>
                <Card hoverable>
                  <Card.Meta
                    avatar={<Avatar icon={<PhoneOutlined />} />}
                    title={clinic.name}
                    description={clinic.address}
                  />
                </Card>
              </List.Item>
            )}
          />
        </>
      )}
    </PageLayout>
  )
}
