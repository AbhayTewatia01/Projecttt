'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Card, Col, Row, Space, Avatar } from 'antd'
import { PhoneOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ClinicDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { enqueueSnackbar } = useSnackbar()
  const [clinic, setClinic] = useState<Model.Clinic | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchClinicDetails = async () => {
      try {
        const clinicDetails = await Api.Clinic.findOne(params.id, {
          includes: ['clinicdoctors', 'clinicdoctors.doctor'],
        })
        setClinic(clinicDetails)
        setLoading(false)
      } catch (error) {
        enqueueSnackbar('Failed to fetch clinic details', { variant: 'error' })
        setLoading(false)
      }
    }

    if (params.id) {
      fetchClinicDetails()
    }
  }, [params.id])

  if (loading) {
    return <PageLayout layout="narrow">Loading...</PageLayout>
  }

  if (!clinic) {
    return <PageLayout layout="narrow">Clinic not found.</PageLayout>
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>{clinic.name}</Title>
      <Text>{clinic.address}</Text>
      <Title level={4} style={{ marginTop: '20px' }}>
        Doctors at this Clinic
      </Title>
      <Row gutter={[16, 16]}>
        {clinic.clinicdoctors?.map(
          clinicDoctor =>
            clinicDoctor.doctor && (
              <Col key={clinicDoctor.doctor.id} xs={24} sm={12} md={8} lg={6}>
                <Card>
                  <Space direction="vertical" align="center">
                    {/* Since Doctor model does not include pictureUrl, we do not attempt to access it */}
                    <Avatar size="large" />
                    <Text strong>{clinicDoctor.doctor.name}</Text>
                    <Text>
                      <PhoneOutlined /> {clinicDoctor.doctor.contactNumber}
                    </Text>
                  </Space>
                </Card>
              </Col>
            ),
        )}
      </Row>
    </PageLayout>
  )
}
